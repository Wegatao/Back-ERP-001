export class Formulario
{
    constructor()
    {
    this.Nome = document.getElementById("section-container-painel-busca-input").value;
    };
}