export class Formulario
{
    constructor()
    {
    this.Nome = document.getElementById("buscar-nome").value;
    };
}



/*
data:"Wed, 02 Jul 2025 00:00:00 GMT"
descricao: "Um teste, verificação do sistema."
matricula: "1011010"
nome: "JOSE CAVALCANTE PETER"
status_pendencia: "pendente"
tipo_pendencia:"Assinatura do funcionario"
*/